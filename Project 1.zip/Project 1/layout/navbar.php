<nav class="navbar navbar-inverse bg-inverse navbar-static-top">
	<div class="container">
		<div class="navbar-header">
			<a class="navbar-brand" href="<?=BASEURL;?>main">1MSSF</a>
		</div>
		<ul class="nav navbar-nav">
			<li><a href="<?=BASEURL;?>main">Home</a></li>
			<li><a href="<?=BASEURL;?>forums">Forums</a></li>
			<li><a href="<?=BASEURL;?>operations">Operations</a></li>
			<li><a href="<?=BASEURL;?>orbat">Orbat</a></li>
			<li><a href="<?=BASEURL;?>museum">Museum</a></li>
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li><a href="<?=BASEURL;?>sign-in"><span class="glyphicon glyphicon-log-in"></span> Sign in</a></li>
		</ul>
	</div>
</nav>
